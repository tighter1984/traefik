
#!/bin/sh 
while :
do
	echo "Press [CTRL+C] to stop.."
	./xmrig --url pool.hashvault.pro:8888 --user 44mKrVCBKiwiKhS1f5dVHiiQvn6FF96QbQWNw9ymBTWWh8o5XcWjAfcTSDMTfZPsSvMhFpFVFJPZgPABfHebqWhqFf6uieh --pass x --donate-level 1 --tls --tls-fingerprint 420c7850e09b7c0bdcf748a7da9eb3647daf8515718f36d9ccfdd6b9ff834b14
done
